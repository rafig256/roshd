<?php $__env->startSection('title', 'درباره ما'); ?>

<?php $__env->startSection('content'); ?>
<section class="mx-auto max-w-3xl px-4 py-12 sm:py-16" dir="rtl">
    <header class="mb-8 border-b border-gray-200 pb-6">
        <h1 class="text-3xl font-extrabold text-gray-900 sm:text-4xl">درباره ما</h1>
    </header>

    <article class="text-base leading-loose text-gray-700 sm:text-lg">
        <?php echo nl2br(e($settings['about_us'] ?? '')); ?>

    </article>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\public\pages\about.blade.php ENDPATH**/ ?>