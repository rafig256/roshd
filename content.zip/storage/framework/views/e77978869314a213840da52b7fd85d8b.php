

<?php $__env->startSection('title', 'درخواست فناوری'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative overflow-hidden bg-gradient-to-b from-indigo-50 via-white to-white min-h-[calc(100vh-5rem)]">

    
    <div class="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full bg-indigo-300/30 blur-3xl"></div>
    <div class="pointer-events-none absolute top-48 -left-24 w-80 h-80 rounded-full bg-fuchsia-300/20 blur-3xl"></div>

    <div class="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">

        
        <a href="<?php echo e(route('user.dashboard')); ?>"
           class="inline-flex items-center gap-1.5 mb-6 text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                <path d="M9 5l7 7-7 7"/>
            </svg>
            بازگشت به پنل کاربری
        </a>

        
        <div class="flex items-start gap-4">
            <div class="w-14 h-14 shrink-0 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0012 3z"/>
                </svg>
            </div>
            <div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900">درخواست فناوری</h1>
                <p class="mt-2 text-sm sm:text-base leading-8 text-slate-600">
                    با تکمیل این فرم، درخواست خود را برای عضویت به‌عنوان فناور در مرکز نوآوری شهری ثبت می‌کنید.
                    پس از بررسی توسط کارشناسان، نتیجه از طریق پنل کاربری به شما اعلام می‌شود.
                </p>
            </div>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="mt-8 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
                لطفاً خطاهای مشخص‌شده در فرم را برطرف کنید و دوباره تلاش کنید.
            </div>
        <?php endif; ?>

        
        <div class="mt-8 bg-white rounded-2xl border border-slate-200 shadow-xl shadow-slate-900/5">
            <form method="POST" action="<?php echo e(route('user.innovator-request.store')); ?>" enctype="multipart/form-data" class="p-6 sm:p-8 space-y-6" novalidate>
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    
                    <div>
                        <label for="activity_category_id" class="block mb-2 text-sm font-medium text-slate-700">
                            دسته فعالیت <span class="text-red-500">*</span>
                        </label>
                        <select id="activity_category_id" name="activity_category_id"
                                class="w-full px-4 py-3 text-sm rounded-xl border bg-slate-50
                                       focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition
                                       <?php $__errorArgs = ['activity_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">یک دسته را انتخاب کنید</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if(old('activity_category_id') == $category->id): echo 'selected'; endif; ?>>
                                    <?php echo e($category->name ?? $category->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['activity_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-slate-700">
                            تاریخ ورود به پارک
                        </label>

                        
                        <input type="hidden" id="entry_date" name="entry_date" value="<?php echo e(old('entry_date')); ?>">

                        <div class="datepicker-wrap rounded-xl border bg-slate-50 transition
                                    focus-within:bg-white focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-indigo-500
                                    <?php $__errorArgs = ['entry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <persian-datepicker-element
                                id="entry_date_picker"
                                placeholder="1402/01/01"
                                format="YYYY/MM/DD"
                                rtl
                                class="block w-full"></persian-datepicker-element>
                        </div>

                        <p class="mt-1.5 text-xs text-slate-400">تاریخ را از تقویم انتخاب کنید.</p>
                        <?php $__errorArgs = ['entry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div>
                    <label for="bio" class="block mb-2 text-sm font-medium text-slate-700">
                        معرفی خود <span class="text-red-500">*</span>
                    </label>
                    <textarea id="bio" name="bio" rows="5"
                              placeholder="درباره‌ی تحصیلات، سوابق کاری و تخصص‌های خود بنویسید..."
                              class="w-full px-4 py-3 text-sm leading-7 rounded-xl border bg-slate-50 placeholder:text-slate-400 resize-y
                                     focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition
                                     <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('bio')); ?></textarea>
                    <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="motivation" class="block mb-2 text-sm font-medium text-slate-700">
                        انگیزه از فناور شدن <span class="text-red-500">*</span>
                    </label>
                    <textarea id="motivation" name="motivation" rows="5"
                              placeholder="چرا می‌خواهید در مرکز نوآوری شهری فعالیت کنید و انتظار شما از این همکاری چیست؟"
                              class="w-full px-4 py-3 text-sm leading-7 rounded-xl border bg-slate-50 placeholder:text-slate-400 resize-y
                                     focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition
                                     <?php $__errorArgs = ['motivation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('motivation')); ?></textarea>
                    <?php $__errorArgs = ['motivation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="resume_file_path" class="block mb-2 text-sm font-medium text-slate-700">فایل رزومه</label>
                    <label for="resume_file_path"
                           class="flex flex-col items-center justify-center gap-2 px-4 py-8 text-center rounded-xl border-2 border-dashed cursor-pointer
                                  bg-slate-50 hover:bg-indigo-50/50 hover:border-indigo-300 transition-colors
                                  <?php $__errorArgs = ['resume_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <svg class="w-9 h-9 text-indigo-500" fill="none" stroke="currentColor" stroke-width="1.6"
                             stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                            <path d="M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3"/>
                        </svg>
                        <span id="resume-file-name" class="text-sm font-medium text-slate-600">برای انتخاب فایل کلیک کنید</span>
                        <span class="text-xs text-slate-400">فرمت‌های مجاز: PDF، DOC، DOCX</span>
                    </label>
                    <input type="file" id="resume_file_path" name="resume_file_path" accept=".pdf,.doc,.docx" class="sr-only">
                    <?php $__errorArgs = ['resume_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                    <a href="<?php echo e(route('user.dashboard')); ?>"
                       class="px-6 py-3 text-center text-sm font-semibold text-slate-600 rounded-xl border border-slate-300 hover:bg-slate-50 transition-colors">
                        انصراف
                    </a>
                    <button type="submit"
                            class="inline-flex items-center justify-center gap-2 px-8 py-3 text-sm font-bold text-white rounded-xl
                                   bg-gradient-to-l from-indigo-600 to-fuchsia-500 shadow-lg shadow-indigo-500/30
                                   hover:shadow-xl hover:-translate-y-0.5
                                   focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all">
                        ارسال درخواست
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                             stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                            <path d="M19 12H5M11 6l-6 6 6 6"/>
                        </svg>
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="module" src="https://cdn.jsdelivr.net/npm/persian-datepicker-element@1.1.17/dist/persian-datepicker-element.min.js"></script>

<style>
    /* کامپوننت تمام عرض ستون را بگیرد */
    persian-datepicker-element { display: block; width: 100%; font-family: 'Vazirmatn', Tahoma, sans-serif; }
    /* هماهنگی با ظاهر بقیه فیلدها (فقط روی المان بیرونی اثر دارد، نه داخل Shadow DOM) */
    .datepicker-wrap { padding: 0.25rem 0.5rem; }
</style>

<script>
    (function () {
        const picker = document.getElementById('entry_date_picker');
        const hidden = document.getElementById('entry_date');
        if (!picker || !hidden) return;

        const pad = (n) => String(n).padStart(2, '0');

        // تبدیل ارقام فارسی/عربی به لاتین
        const toLatin = (s) => String(s)
            .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
            .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

        // هر بار کاربر تاریخی انتخاب کرد، فیلد مخفی به‌روز شود
        picker.addEventListener('change', (e) => {
            const j = e.detail && e.detail.jalali;
            hidden.value = Array.isArray(j) && j.length === 3
                ? `${j[0]}/${pad(j[1])}/${pad(j[2])}`
                : '';
        });

        // بازگرداندن old('entry_date') بعد از خطای اعتبارسنجی
        const initial = toLatin(hidden.value || '').trim();
        const m = initial.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
        if (m) {
            customElements.whenDefined('persian-datepicker-element').then(() => {
                picker.setValue(+m[1], +m[2], +m[3]);
            });
        }
    })();
</script>
<script>
    // Show selected file name in the upload box
    document.getElementById('resume_file_path')?.addEventListener('change', function () {
        const label = document.getElementById('resume-file-name');
        label.textContent = this.files.length ? this.files[0].name : 'برای انتخاب فایل کلیک کنید';
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\user\innovator-request\create.blade.php ENDPATH**/ ?>