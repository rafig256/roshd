<?php $__env->startSection('title', 'ویرایش خبر'); ?>
<?php $__env->startSection('page-title', 'ویرایش خبر'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
    <style>
        .ts-wrapper .ts-control {
            @apply w-full px-4 py-2.5 text-sm rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none;
            min-height: 46px;
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
        }
        .ts-wrapper.focus .ts-control {
            @apply ring-2 ring-indigo-500 border-indigo-500;
        }
        .ts-dropdown {
            @apply text-sm rounded-lg border border-slate-300 shadow-lg;
            direction: rtl;
            text-align: right;
        }
        .ts-dropdown .option {
            @apply px-3 py-2 text-slate-700 hover:bg-slate-50 cursor-pointer;
        }
        .ts-dropdown .active {
            @apply bg-indigo-50 text-indigo-700;
        }
        .ts-wrapper.multi .ts-control {
            background-position: left 0.75rem center !important;
            padding-left: 2rem !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">

    <div class="mb-6">
        <h2 class="text-xl font-bold text-slate-800">فرم ویرایش خبر</h2>
        <p class="mt-1 text-sm text-slate-500">اطلاعات خبر را در این صفحه ویرایش کنید.</p>
    </div>

    <form method="POST" action="<?php echo e(route('admin.news.update', $news->id)); ?>" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div>
            <label for="title" class="block mb-2 text-sm font-medium text-slate-700">عنوان خبر <span class="text-red-500">*</span></label>
            <input type="text" id="title" name="title" value="<?php echo e(old('title', $news->title)); ?>"
                   class="w-full px-4 py-2.5 text-sm rounded-lg border bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="categories" class="block mb-2 text-sm font-medium text-slate-700">دسته‌بندی‌ها <span class="text-red-500">*</span></label>
            <select id="categories" name="categories[]" multiple placeholder="جستجوی دسته‌بندی‌ها..."
                    class="w-full <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e($news->categories->contains($category->id) ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="mt-1.5 text-xs text-slate-400">حداقل یک دسته‌بندی انتخاب کنید.</p>
            <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="excerpt" class="block mb-2 text-sm font-medium text-slate-700">خلاصه (Excerpt)</label>
            <textarea id="excerpt" name="excerpt" rows="3"
                      class="w-full px-4 py-2.5 text-sm rounded-lg border bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('excerpt', $news->excerpt)); ?></textarea>
            <p class="mt-1.5 text-xs text-slate-400">خلاصه کوتاه خبر برای نمایش در لیست‌ها و کارت‌ها.</p>
            <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="body" class="block mb-2 text-sm font-medium text-slate-700">متن کامل خبر <span class="text-red-500">*</span></label>
            <textarea id="body" name="body" rows="15"
                      class="w-full px-4 py-2.5 text-sm rounded-lg border bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('body', $news->body)); ?></textarea>
            <p class="mt-1.5 text-xs text-slate-400">متن کامل خبر. ویرایشگر متن غنی در آینده اضافه خواهد شد.</p>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label for="cover_image" class="block mb-2 text-sm font-medium text-slate-700">تصویر کاور</label>
            <?php if($news->cover_image_path): ?>
                <div class="mb-3">
                    <img src="<?php echo e(route('file.news-cover', basename($news->cover_image_path))); ?>"
                         alt="<?php echo e($news->title); ?>"
                         class="max-w-xs rounded-xl object-cover border border-slate-200">
                    <p class="mt-1 text-xs text-slate-400">انتخاب تصویر جدید، تصویر قبلی را جایگزین می‌کند.</p>
                </div>
            <?php endif; ?>
            <label for="cover_image"
                   class="flex flex-col items-center justify-center gap-2 px-4 py-8 text-center rounded-xl border-2 border-dashed cursor-pointer
                          bg-slate-50 hover:bg-indigo-50/50 hover:border-indigo-300 transition-colors
                          <?php $__errorArgs = ['cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <img id="cover-preview" alt="پیش‌نمایش کاور" class="hidden max-w-xs rounded-xl object-cover border border-slate-200">
                <svg id="cover-icon" class="w-9 h-9 text-indigo-500" fill="none" stroke="currentColor" stroke-width="1.6"
                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M3 5a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5zM3 16l5-5 4 4 3-3 6 6M8.5 8.5h.01"/>
                </svg>
                <span id="cover-file-name" class="text-sm font-medium text-slate-600">برای انتخاب تصویر جدید کلیک کنید</span>
                <span class="text-xs text-slate-400">فرمت‌های مجاز: PNG، JPG، WEBP (حداکثر ۲ مگابایت)</span>
            </label>
            <input type="file" id="cover_image" name="cover_image" accept=".png,.jpg,.jpeg,.webp" class="sr-only">
            <?php $__errorArgs = ['cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div>
                <label for="status" class="block mb-2 text-sm font-medium text-slate-700">وضعیت <span class="text-red-500">*</span></label>
                <select id="status" name="status"
                        class="w-full px-4 py-2.5 text-sm rounded-lg border bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="draft" <?php echo e(old('status', $news->status->value) === 'draft' ? 'selected' : ''); ?>>پیش‌نویس</option>
                    <option value="published" <?php echo e(old('status', $news->status->value) === 'published' ? 'selected' : ''); ?>>منتشر شده</option>
                    <option value="archived" <?php echo e(old('status', $news->status->value) === 'archived' ? 'selected' : ''); ?>>بایگانی شده</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="block mb-2 text-sm font-medium text-slate-700">تنظیمات</label>
                <div class="flex items-center gap-2">
                    <input type="checkbox" id="is_featured" name="is_featured" value="1"
                           <?php echo e(old('is_featured', $news->is_featured) ? 'checked' : ''); ?>

                           class="w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-2 focus:ring-indigo-500">
                    <label for="is_featured" class="text-sm font-medium text-slate-700 cursor-pointer">ویژه</label>
                </div>
            </div>
        </div>

        
        <div class="flex justify-end pt-4">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7"/>
                </svg>
                ذخیره تغییرات
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // TomSelect for categories
            new TomSelect('#categories', {
                plugins: ['remove_button'],
                maxItems: null,
                create: false,
                placeholder: 'جستجوی دسته‌بندی‌ها...',
                dir: 'rtl',
            });

            // Cover image preview
            document.getElementById('cover_image')?.addEventListener('change', function () {
                const name    = document.getElementById('cover-file-name');
                const preview = document.getElementById('cover-preview');
                const icon    = document.getElementById('cover-icon');
                const file    = this.files[0];

                if (!file) {
                    name.textContent = 'برای انتخاب تصویر جدید کلیک کنید';
                    preview.classList.add('hidden');
                    icon.classList.remove('hidden');
                    return;
                }

                name.textContent = file.name;
                preview.src = URL.createObjectURL(file);
                preview.classList.remove('hidden');
                icon.classList.add('hidden');
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\admin\news\edit.blade.php ENDPATH**/ ?>