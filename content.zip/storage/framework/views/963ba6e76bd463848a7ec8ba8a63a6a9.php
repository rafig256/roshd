<?php $__env->startSection('title', 'مدیریت کاربران'); ?>
<?php $__env->startSection('page-title', 'مدیریت کاربران'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl">

        
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h2 class="text-xl font-bold text-slate-800">مدیریت کاربران</h2>
                <p class="mt-1 text-sm text-slate-500">لیست کاربران ثبت‌شده در سیستم را اینجا مدیریت کنید.</p>
            </div>

            <a href="<?php echo e(route('admin.users.create')); ?>"
               class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-lg
                      hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500
                      transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M12 5v14m-7-7h14"/>
                </svg>
                کاربر جدید
            </a>

            <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="flex items-center gap-2">
                <input type="text"
                       name="search"
                       value="<?php echo e(request('search')); ?>"
                       placeholder="جستجو بر اساس نام، کد ملی یا موبایل..."
                       class="px-4 py-2.5 text-sm rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none w-full md:w-80">
                <button type="submit"
                        class="px-4 py-2.5 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
                    جستجو
                </button>
            </form>
        </div>

        
        <?php if(session('success')): ?>
            <div class="mb-6 flex items-center gap-2 px-4 py-3 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg">
                <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7"/>
                </svg>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <table class="w-full text-left text-sm">
                <thead class="bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">نام و نام خانوادگی</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">کد ملی</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">موبایل</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">نقش‌ها</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">فناور؟</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-slate-700">مسدود/آزاد</th>
                        <th class="px-6 py-3 text-right text-sm font-semibold text-slate-700 w-20">عملیات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="px-6 py-4 text-slate-800"><?php echo e($user->name); ?> <?php echo e($user->family); ?></td>
                            <td class="px-6 py-4 text-slate-800" dir="ltr"><?php echo e($user->national_code); ?></td>
                            <td class="px-6 py-4 text-slate-800" dir="ltr"><?php echo e($user->mobile); ?></td>
                            <td class="px-6 py-4 text-slate-800">
                                <?php echo e($user->roles->isNotEmpty() ? $user->roles->pluck('label')->implode(', ') : 'کاربر عادی'); ?>

                            </td>
                            <td class="px-6 py-4">
                                <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium
                                           <?php echo e($user->is_innovator ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'); ?>">
                                    <?php echo e($user->is_innovator ? 'بله' : 'خیر'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($user->status === 'blocked'): ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">مسدود</span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">فعال</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center gap-2 justify-end">
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                       class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-indigo-600 bg-indigo-50 rounded-md hover:bg-indigo-100 transition-colors">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2"
                                             stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                        </svg>
                                        ویرایش
                                    </a>
                                    
                                    
                                    <form action="<?php echo e(route('admin.users.toggle-block', $user->id)); ?>" method="POST" class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php if($user->status === 'blocked'): ?>
                                            <button type="submit"
                                                    class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 rounded-md hover:bg-emerald-100 transition-colors"
                                                    onclick="return confirm('آیا از آزاد کردن این کاربر مطمئن هستید؟');">
                                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2"
                                                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                                    <path d="M12 15v-9m0 0l-3 3m3-3l3 3m-3-3h9"/>
                                                </svg>
                                                آزاد کردن
                                            </button>
                                        <?php else: ?>
                                            <button type="submit"
                                                    class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100 transition-colors"
                                                    onclick="return confirm('آیا از مسدود کردن این کاربر مطمئن هستید؟');">
                                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2"
                                                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                                    <path d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                                مسدود کردن
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                    
                                    <?php if(auth()->id() !== $user->id): ?>
                                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST"
                                          onsubmit="return confirm('آیا از حذف این کاربر مطمئن هستید؟')"
                                          class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100 transition-colors">
                                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2"
                                                 stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                                <path d="M3 6h18"/>
                                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                            </svg>
                                            حذف
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">کاربری یافت نشد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="mt-6">
            <?php echo e($users->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\admin\users\index.blade.php ENDPATH**/ ?>