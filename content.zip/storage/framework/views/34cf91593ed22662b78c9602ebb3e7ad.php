

<?php $__env->startSection('title', 'ثبت‌نام'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative overflow-hidden min-h-[calc(100vh-5rem)] flex items-center justify-center px-4 py-12
                bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">

    
    <div class="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full bg-indigo-600/40 blur-3xl"></div>
    <div class="pointer-events-none absolute top-1/3 -left-24 w-80 h-80 rounded-full bg-fuchsia-500/30 blur-3xl"></div>
    <div class="pointer-events-none absolute -bottom-24 right-1/3 w-96 h-96 rounded-full bg-cyan-500/20 blur-3xl"></div>

    
    <div class="relative w-full max-w-2xl">
        <div class="rounded-3xl border border-white/15 bg-white/10 backdrop-blur-xl shadow-2xl shadow-black/30 p-6 sm:p-10">

            
            <div class="text-center mb-8">
                <span class="inline-flex items-center gap-2 px-3 py-1 mb-4 text-xs font-medium text-indigo-200 bg-white/10 rounded-full border border-white/10">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    همین امروز مسیر استارتاپ خود را شروع کنید
                </span>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-white">ساخت حساب کاربری</h1>
                <p class="mt-2 text-sm text-slate-300">برای عضویت در جامعه نوآوران، اطلاعات زیر را تکمیل کنید.</p>
            </div>

            <form method="POST" action="<?php echo e(route('register.submit')); ?>" class="space-y-5" novalidate>
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-slate-200">نام</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>"
                               autocomplete="given-name" placeholder="مثلاً علی"
                               class="w-full px-4 py-3 text-sm text-white placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="family" class="block mb-2 text-sm font-medium text-slate-200">نام خانوادگی</label>
                        <input type="text" id="family" name="family" value="<?php echo e(old('family')); ?>"
                               autocomplete="family-name" placeholder="مثلاً رضایی"
                               class="w-full px-4 py-3 text-sm text-white placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="national_code" class="block mb-2 text-sm font-medium text-slate-200">کد ملی</label>
                        <input type="text" id="national_code" name="national_code" value="<?php echo e(old('national_code')); ?>"
                               dir="ltr" inputmode="numeric" maxlength="10" placeholder="۱۰ رقم"
                               class="w-full px-4 py-3 text-sm text-left text-white placeholder:text-right placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="mobile" class="block mb-2 text-sm font-medium text-slate-200">شماره موبایل</label>
                        <input type="text" id="mobile" name="mobile" value="<?php echo e(old('mobile')); ?>"
                               dir="ltr" inputmode="tel" maxlength="11" autocomplete="tel" placeholder="09123456789"
                               class="w-full px-4 py-3 text-sm text-left text-white placeholder:text-right placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="password" class="block mb-2 text-sm font-medium text-slate-200">رمز عبور</label>
                        <input type="password" id="password" name="password"
                               dir="ltr" autocomplete="new-password" placeholder="حداقل ۸ کاراکتر"
                               class="w-full px-4 py-3 text-sm text-left text-white placeholder:text-right placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="password_confirmation" class="block mb-2 text-sm font-medium text-slate-200">تکرار رمز عبور</label>
                        <input type="password" id="password_confirmation" name="password_confirmation"
                               dir="ltr" autocomplete="new-password" placeholder="رمز عبور را دوباره وارد کنید"
                               class="w-full px-4 py-3 text-sm text-left text-white placeholder:text-right placeholder:text-slate-400 rounded-xl bg-white/10 border
                                      focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/15 transition
                                      <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-white/20 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-300"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <button type="submit"
                        class="w-full py-3.5 text-sm font-bold text-white rounded-xl bg-gradient-to-l from-indigo-500 to-fuchsia-500
                               shadow-lg shadow-indigo-900/40 hover:shadow-xl hover:-translate-y-0.5
                               focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-indigo-400
                               transition-all">
                    ثبت‌نام
                </button>
            </form>

            <p class="mt-6 text-center text-sm text-slate-300">
                قبلاً ثبت‌نام کرده‌اید؟
                <a href="#" class="font-semibold text-indigo-300 hover:text-white underline-offset-4 hover:underline transition-colors">
                    وارد شوید
                </a>
            </p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\auth\register.blade.php ENDPATH**/ ?>