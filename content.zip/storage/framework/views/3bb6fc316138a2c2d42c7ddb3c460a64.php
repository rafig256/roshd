

<?php $__env->startSection('title', 'مدیریت تیم'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // وضعیت تیم (پشتیبانی از enum و رشته)
    $orgStatusValue = $organization->status instanceof \BackedEnum ? $organization->status->value : $organization->status;
    $orgStatusLabel = $organization->status instanceof \BackedEnum && method_exists($organization->status, 'label')
        ? $organization->status->label()
        : match ($orgStatusValue) {
            'team'            => 'تیم',
            'pending_company' => 'در انتظار تبدیل به شرکت',
            'company'         => 'شرکت رسمی',
            'pending'         => 'در انتظار تأیید',
            'approved'        => 'تأیید شده',
            'rejected'        => 'رد شده',
            default           => $orgStatusValue ?: 'نامشخص',
        };
    $orgStatusClass = match ($orgStatusValue) {
        'company', 'approved'        => 'bg-emerald-100 text-emerald-800 border-emerald-200',
        'pending_company', 'pending' => 'bg-amber-100 text-amber-800 border-amber-200',
        'rejected'                   => 'bg-red-100 text-red-800 border-red-200',
        'team'                       => 'bg-sky-100 text-sky-800 border-sky-200',
        default                      => 'bg-slate-100 text-slate-700 border-slate-200',
    };

    // اعضای فعال و درخواست‌های عضویت (از کنترلر یا از رابطه‌ها)
    $members      = $members      ?? $organization->members      ?? collect();
    $joinRequests = $joinRequests ?? $organization->joinRequests ?? collect();

    $createdAt = $organization->created_at
        ? \Morilog\Jalali\Jalalian::fromCarbon($organization->created_at)->format('Y/m/d')
        : null;
?>

<section class="relative overflow-hidden bg-gradient-to-b from-indigo-50 via-white to-white min-h-[calc(100vh-5rem)]">

    
    <div class="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full bg-indigo-300/30 blur-3xl"></div>
    <div class="pointer-events-none absolute top-48 -left-24 w-80 h-80 rounded-full bg-fuchsia-300/20 blur-3xl"></div>

    <div class="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">

        
        <a href="<?php echo e(route('user.dashboard')); ?>"
           class="inline-flex items-center gap-1.5 mb-6 text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
            بازگشت به پنل کاربری
        </a>

        
        <?php if(session('success')): ?>
            <div class="mb-6 flex items-center gap-2 px-4 py-3 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl">
                <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="mb-6 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="mb-6 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-xl shadow-slate-900/5 p-6 sm:p-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-5">
                <div class="flex items-center gap-4 min-w-0">
                    <?php if(!empty($organization->logo_path)): ?>
                        <img src="<?php echo e(route('file.logo', basename($organization->logo_path))); ?>" alt="<?php echo e($organization->name); ?>"
                             class="w-20 h-20 shrink-0 rounded-2xl object-cover border border-slate-200">
                    <?php else: ?>
                        <div class="w-20 h-20 shrink-0 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 text-white flex items-center justify-center text-3xl font-extrabold shadow-lg shadow-cyan-500/30">
                            <?php echo e(mb_substr($organization->name, 0, 1)); ?>

                        </div>
                    <?php endif; ?>

                    <div class="min-w-0">
                        <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 truncate"><?php echo e($organization->name); ?></h1>
                        <span class="mt-2 inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-full border <?php echo e($orgStatusClass); ?>">
                            <span class="w-1.5 h-1.5 rounded-full bg-current"></span>
                            <?php echo e($orgStatusLabel); ?>

                        </span>
                    </div>
                </div>

                <div class="flex flex-col items-stretch sm:items-end gap-2 shrink-0">

                    <?php if(!auth()->user()->isBlocked()): ?>
                        <a href="<?php echo e(route('user.organizations.edit', $organization->id)); ?>"
                        class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-bold text-indigo-700 bg-indigo-50 rounded-xl
                                hover:bg-indigo-100 transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M16 3l5 5L8 21H3v-5L16 3z"/></svg>
                            ویرایش اطلاعات تیم
                        </a>

                        <?php if($orgStatusValue === 'team'): ?>
                            <a href="<?php echo e(route('user.organizations.convert-to-company', $organization->id)); ?>"
                            class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-bold text-white rounded-xl
                                    bg-gradient-to-l from-indigo-600 to-fuchsia-500 shadow-md shadow-indigo-500/30
                                    hover:shadow-lg hover:-translate-y-0.5 transition-all">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M3 21h18M5 21V5a2 2 0 012-2h10a2 2 0 012 2v16M9 7h2M13 7h2M9 11h2M13 11h2M10 21v-4h4v4"/></svg>
                                درخواست تبدیل به شرکت
                            </a>
                        <?php elseif($orgStatusValue === 'pending_company'): ?>
                            <span class="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold text-amber-800 bg-amber-100 border border-amber-200 rounded-xl">
                                <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                                درخواست تبدیل به شرکت در حال بررسی است.
                            </span>
                        <?php elseif($orgStatusValue === 'company'): ?>
                            <span class="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold text-emerald-800 bg-emerald-100 border border-emerald-200 rounded-xl">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
                                شرکت رسمی
                            </span>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="flex flex-col items-stretch sm:items-end gap-2 shrink-0">
                            <button type="button" disabled
                                    class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-bold text-slate-400 bg-slate-100 rounded-xl cursor-not-allowed">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M16 3l5 5L8 21H3v-5L16 3z"/></svg>
                                ویرایش اطلاعات تیم (حساب مسدود)
                            </button>
                            <span class="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold text-red-800 bg-red-100 border border-red-200 rounded-xl">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01M12 21a9 9 0 110-18 9 9 0 010 18z"/></svg>
                                حساب شما مسدود است - امکان انجام عملیات وجود ندارد
                            </span>
                        </div>
                    <?php endif; ?>
            </div>
        </div>

        <div class="mt-6 space-y-6">

            
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm">
                <div class="px-6 py-4 border-b border-slate-200 flex items-center gap-3">
                    <span class="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M12 21a9 9 0 100-18 9 9 0 000 18zM12 8h.01M11 12h1v4h1"/></svg>
                    </span>
                    <h2 class="text-base font-semibold text-slate-800">اطلاعات تیم</h2>
                </div>
                <dl class="p-6 space-y-5">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-5">
                        <div>
                            <dt class="text-xs text-slate-400">دسته فعالیت</dt>
                            <dd class="mt-1 text-sm font-medium text-slate-800"><?php echo e($organization->activityCategory->name ?? 'ثبت نشده'); ?></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-slate-400">تاریخ ایجاد</dt>
                            <dd class="mt-1 text-sm font-medium text-slate-800">
                                <?php if($createdAt): ?>
                                    <span dir="ltr" class="inline-block"><?php echo e($createdAt); ?></span>
                                <?php else: ?>
                                    <span class="text-slate-400">ثبت نشده</span>
                                <?php endif; ?>
                            </dd>
                        </div>
                    </div>
                    <div>
                        <dt class="text-xs text-slate-400">توضیحات</dt>
                        <dd class="mt-2 p-4 text-sm leading-8 text-slate-700 bg-slate-50 rounded-lg border border-slate-100 whitespace-pre-line"><?php echo e($organization->description ?: 'توضیحاتی ثبت نشده است.'); ?></dd>
                    </div>
                </dl>
            </div>

            
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm">
                <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M16 11a4 4 0 10-8 0 4 4 0 008 0zM4 20a8 8 0 0113-6.2M19 14v6M16 17h6"/></svg>
                        </span>
                        <h2 class="text-base font-semibold text-slate-800">درخواست‌های عضویت</h2>
                    </div>
                    <?php if($joinRequests->count()): ?>
                        <span class="px-2.5 py-0.5 text-xs font-bold text-amber-800 bg-amber-100 rounded-full"><?php echo e($joinRequests->count()); ?> درخواست</span>
                    <?php endif; ?>
                </div>

                <?php if($joinRequests->isEmpty()): ?>
                    <div class="px-6 py-12 text-center">
                        <p class="text-sm font-medium text-slate-500">درخواست عضویت جدیدی وجود ندارد.</p>
                    </div>
                <?php else: ?>
                    <ul class="divide-y divide-slate-100">
                        <?php $__currentLoopData = $joinRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joinRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $reqUser = $joinRequest->user;
                                $reqName = trim(($reqUser?->name ?? '') . ' ' . ($reqUser?->family ?? ''));
                            ?>
                            <li class="px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                                <div class="flex items-center gap-3 min-w-0">
                                    <div class="w-10 h-10 shrink-0 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-sm font-bold">
                                        <?php echo e(mb_substr($reqName !== '' ? $reqName : '؟', 0, 1)); ?>

                                    </div>
                                    <div class="min-w-0">
                                        <p class="text-sm font-semibold text-slate-800 truncate"><?php echo e($reqName !== '' ? $reqName : 'کاربر نامشخص'); ?></p>
                                        <p class="text-xs text-slate-400">
                                            ارسال‌شده در
                                            <?php if($joinRequest->created_at): ?>
                                                <span dir="ltr" class="inline-block"><?php echo e(\Morilog\Jalali\Jalalian::fromCarbon($joinRequest->created_at)->format('Y/m/d')); ?></span>
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </p>
                                        <p class="text-xs text-slate-400"> متن درخواست: <?php echo e($joinRequest->message); ?> </p>
                                    </div>
                                </div>

                                <div class="flex items-center gap-2 shrink-0">
                                    <?php if(!auth()->user()->isBlocked()): ?>
                                        <form method="POST" action="<?php echo e(route('user.organizations.join-requests.approve', [$organization->id, $joinRequest->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit"
                                                    class="px-4 py-2 text-xs font-bold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors">
                                                تأیید
                                            </button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('user.organizations.join-requests.reject', [$organization->id, $joinRequest->id])); ?>"
                                              onsubmit="return confirm('آیا از رد این درخواست مطمئن هستید؟');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit"
                                                    class="px-4 py-2 text-xs font-bold text-red-700 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
                                                رد
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button type="button" disabled
                                                class="px-4 py-2 text-xs font-bold text-slate-400 bg-slate-100 rounded-lg cursor-not-allowed">
                                            تأیید (مسدود)
                                        </button>
                                        <button type="button" disabled
                                                class="px-4 py-2 text-xs font-bold text-slate-400 bg-slate-100 rounded-lg cursor-not-allowed">
                                            رد (مسدود)
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-4.13a4 4 0 11-8 0 4 4 0 018 0zm6 0a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        </span>
                        <h2 class="text-base font-semibold text-slate-800">اعضای تیم</h2>
                    </div>
                    <?php if($members->count()): ?>
                        <span class="px-2.5 py-0.5 text-xs font-bold text-cyan-800 bg-cyan-100 rounded-full"><?php echo e($members->count()); ?> عضو</span>
                    <?php endif; ?>
                </div>

                <?php if($members->isEmpty()): ?>
                    <div class="px-6 py-12 text-center">
                        <p class="text-sm font-medium text-slate-500">هنوز عضوی به تیم اضافه نشده است.</p>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm text-right">
                            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
                                <tr>
                                    <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">نام</th>
                                    <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">سمت</th>
                                    <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">عملیات</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $memUser = $member->user;
                                        $memName = trim(($memUser?->name ?? '') . ' ' . ($memUser?->family ?? ''));
                                        $isRep   = ($memUser?->id ?? $member->user_id) === $organization->representative_id;
                                    ?>
                                    <tr class="hover:bg-slate-50/70 transition-colors">
                                        
                                        <td class="px-5 py-4 whitespace-nowrap">
                                            <div class="flex items-center gap-3">
                                                <div class="w-9 h-9 shrink-0 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-sm font-bold">
                                                    <?php echo e(mb_substr($memName !== '' ? $memName : '؟', 0, 1)); ?>

                                                </div>
                                                <div>
                                                    <p class="font-semibold text-slate-800"><?php echo e($memName !== '' ? $memName : 'کاربر نامشخص'); ?></p>
                                                    <?php if($isRep): ?>
                                                        <span class="inline-block mt-0.5 px-2 py-0.5 text-[11px] font-bold text-indigo-700 bg-indigo-50 rounded-full">نماینده‌ی تیم</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>

                                        
                                        <td class="px-5 py-4">
                                            <?php if(!auth()->user()->isBlocked()): ?>
                                                <form method="POST"
                                                      action="<?php echo e(route('user.organizations.members.update', [$organization->id, $member->id])); ?>"
                                                      class="flex items-center gap-2 min-w-[16rem]">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="text" name="position" value="<?php echo e($member->position); ?>"
                                                           maxlength="100" placeholder="سمت (مثلاً توسعه‌دهنده)"
                                                           aria-label="سمت <?php echo e($memName); ?>"
                                                           class="flex-1 min-w-0 px-3 py-2 text-xs rounded-lg border border-slate-300 bg-slate-50 placeholder:text-slate-400
                                                                      focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
                                                    <button type="submit"
                                                            class="px-3.5 py-2 text-xs font-bold text-indigo-700 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors">
                                                        ذخیره
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <div class="flex items-center gap-2 min-w-[16rem]">
                                                    <input type="text" value="<?php echo e($member->position); ?>" disabled
                                                           maxlength="100" placeholder="سمت (مثلاً توسعه‌دهنده)"
                                                           aria-label="سمت <?php echo e($memName); ?>"
                                                           class="flex-1 min-w-0 px-3 py-2 text-xs rounded-lg border border-slate-300 bg-slate-100 placeholder:text-slate-400 cursor-not-allowed">
                                                    <button type="button" disabled
                                                            class="px-3.5 py-2 text-xs font-bold text-slate-400 bg-slate-100 rounded-lg cursor-not-allowed">
                                                        ذخیره (مسدود)
                                                    </button>
                                                </div>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td class="px-5 py-4 whitespace-nowrap">
                                            <?php if (! ($isRep)): ?>
                                                <?php if(!auth()->user()->isBlocked()): ?>
                                                    <form method="POST"
                                                          action="<?php echo e(route('user.organizations.members.destroy', [$organization->id, $member->id])); ?>"
                                                          onsubmit="return confirm('آیا از حذف این عضو از تیم مطمئن هستید؟');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                                class="px-3.5 py-2 text-xs font-bold text-red-700 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
                                                            حذف
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <button type="button" disabled
                                                            class="px-3.5 py-2 text-xs font-bold text-slate-400 bg-slate-100 rounded-lg cursor-not-allowed">
                                                        حذف (مسدود)
                                                    </button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-xs text-slate-400">—</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\user\organizations\show.blade.php ENDPATH**/ ?>