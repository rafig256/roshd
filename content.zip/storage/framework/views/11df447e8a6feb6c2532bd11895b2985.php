

<?php $__env->startSection('title', 'ایجاد رویداد'); ?>
<?php $__env->startSection('page-title', 'ایجاد رویداد'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">

    <div class="mb-6">
        <h2 class="text-xl font-bold text-slate-800">ایجاد رویداد جدید</h2>
        <p class="mt-1 text-sm text-slate-500">اطلاعات رویداد، زمان‌بندی، سخنرانان و برنامه‌ی جلسات را وارد کنید.</p>
    </div>

    <?php if(session('error')): ?>
        <div class="mb-6 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php echo $__env->make('admin.events._form', [
        'action' => route('admin.events.store'),
        'method' => 'POST',
        'event'  => null,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\admin\events\create.blade.php ENDPATH**/ ?>