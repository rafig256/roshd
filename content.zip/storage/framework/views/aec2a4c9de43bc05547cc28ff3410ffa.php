<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'theme' => null,
    'mode' => null,
    'defaultPosition' => 'top-right',
    'assets' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'theme' => null,
    'mode' => null,
    'defaultPosition' => 'top-right',
    'assets' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (! $__env->hasRenderedOnce('c1949844-946d-4936-ac56-ffec12272090')): $__env->markAsRenderedOnce('c1949844-946d-4936-ac56-ffec12272090'); ?>
    <?php if($assets): ?>
        <link rel="stylesheet" href="<?php echo e(asset('vendor/wiretoast/css/wiretoast.css')); ?>">
        <script src="<?php echo e(asset('vendor/wiretoast/js/wiretoast.js')); ?>" defer></script>
    <?php endif; ?>
<?php endif; ?>

<div id="wt-root"
    <?php if($theme): ?> data-wt-theme="<?php echo e($theme); ?>" <?php endif; ?>
    <?php if($mode): ?> data-wt-theme-mode="<?php echo e($mode); ?>" <?php endif; ?>
    data-wt-default-position="<?php echo e($defaultPosition); ?>">
    <?php $__currentLoopData = ['top-left', 'top-center', 'top-right', 'bottom-left', 'bottom-center', 'bottom-right', 'center']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="wt-container" data-wt-position="<?php echo e($pos); ?>"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\rafig\project\roshd\vendor\edulazaro\wiretoast\resources\views\components\wiretoast.blade.php ENDPATH**/ ?>