<?php $__env->startSection('title', 'مدیریت رویدادها'); ?>
<?php $__env->startSection('page-title', 'مدیریت رویدادها'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $locationLabels = [
        'physical' => 'حضوری',
        'online'   => 'آنلاین',
        'hybrid'   => 'ترکیبی',
    ];
    $locationStyles = [
        'physical' => 'bg-indigo-50 text-indigo-700',
        'online'   => 'bg-cyan-50 text-cyan-700',
        'hybrid'   => 'bg-fuchsia-50 text-fuchsia-700',
    ];

    // رنگ‌ها به‌صورت کلاس کامل (برای سازگاری با build تیلویند)
    $statusStyles = [
        'draft'     => ['class' => 'bg-amber-100 text-amber-800 border-amber-200',       'dot' => 'bg-amber-500'],
        'published' => ['class' => 'bg-emerald-100 text-emerald-800 border-emerald-200', 'dot' => 'bg-emerald-500'],
        'cancelled' => ['class' => 'bg-red-100 text-red-800 border-red-200',             'dot' => 'bg-red-500'],
        'finished'  => ['class' => 'bg-slate-100 text-slate-700 border-slate-200',       'dot' => 'bg-slate-400'],
    ];
?>

<div>
    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-800">رویدادها</h2>
            <p class="mt-1 text-sm text-slate-500">رویدادهای مرکز را ایجاد، ویرایش و مدیریت کنید.</p>
        </div>
        <a href="<?php echo e(route('admin.events.create')); ?>"
           class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-bold text-white bg-indigo-600 rounded-lg
                  hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            ایجاد رویداد جدید
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-6 flex items-center gap-2 px-4 py-3 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg">
            <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-6 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <form method="GET" action="<?php echo e(route('admin.events.index')); ?>" class="mb-4 flex flex-col sm:flex-row gap-2">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="جست‌وجو در عنوان یا نشانک (slug)..."
               aria-label="جست‌وجو"
               class="flex-1 px-4 py-2.5 text-sm rounded-lg border border-slate-300 bg-white placeholder:text-slate-400
                      focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition">
        <div class="flex gap-2">
            <button type="submit"
                    class="px-5 py-2.5 text-sm font-semibold text-white bg-slate-800 rounded-lg hover:bg-slate-900 transition-colors">
                جست‌وجو
            </button>
            <?php if(request()->filled('search')): ?>
                <a href="<?php echo e(route('admin.events.index')); ?>"
                   class="px-5 py-2.5 text-sm font-semibold text-slate-600 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                    پاک کردن
                </a>
            <?php endif; ?>
        </div>
    </form>

    
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-right">
                <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <tr>
                        <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">عنوان</th>
                        <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">تاریخ شروع</th>
                        <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">نوع برگزاری</th>
                        <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">وضعیت</th>
                        <th scope="col" class="px-5 py-3.5 font-semibold whitespace-nowrap">عملیات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50/70 transition-colors">
                            <td class="px-5 py-4 max-w-xs">
                                <span class="font-semibold text-slate-800 line-clamp-2"><?php echo e($event->title); ?></span>
                            </td>
                            <td class="px-5 py-4 text-slate-600 whitespace-nowrap">
                                <?php echo e($event->jalali_date_only); ?>

                            </td>
                            <td class="px-5 py-4 whitespace-nowrap">
                                <?php
                                    $locValue = $event->location_type instanceof \BackedEnum ? $event->location_type->value : $event->location_type;
                                    $locLabel = $locationLabels[$locValue] ?? ($locValue ?: 'نامشخص');
                                    $locClass = $locationStyles[$locValue] ?? 'bg-slate-100 text-slate-700';
                                ?>
                                <span class="inline-block px-3 py-1 text-xs font-semibold rounded-full <?php echo e($locClass); ?>"><?php echo e($locLabel); ?></span>
                            </td>
                            <td class="px-5 py-4 whitespace-nowrap">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($event->status->badgeClasses() ?? 'bg-gray-100 text-gray-800'); ?>"><?php echo e($event->status->label() ?? 'نامشخص'); ?></span>
                            </td>
                            <td class="px-5 py-4 whitespace-nowrap">
                                <div class="flex items-center gap-2">
                                    <a href="<?php echo e(route('admin.events.edit', $event->id)); ?>"
                                       class="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M16 3l5 5L8 21H3v-5L16 3z"/></svg>
                                        ویرایش
                                    </a>

                                    <form method="POST" action="<?php echo e(route('admin.events.destroy', $event->id)); ?>"
                                          onsubmit="return confirm('آیا از حذف این رویداد مطمئن هستید؟ این عمل قابل بازگشت نیست.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-red-700 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 002 2h6a2 2 0 002-2l1-12M9 7V4h6v3"/></svg>
                                            حذف
                                        </button>
                                    </form>
                                    <a href="<?php echo e(route('admin.events.registrations', $event->id)); ?>" 
                                    class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 rounded-md hover:bg-blue-100 transition-colors">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-4.13a4 4 0 11-8 0 4 4 0 018 0zm6 0a3 3 0 11-6 0 3 3 0 016 0z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                        ثبت‌نامی‌ها
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-5 py-16 text-center">
                                <div class="mx-auto w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
                                    <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                                        <path d="M8 7V3m8 4V3M4 11h16M5 5h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1z"/>
                                    </svg>
                                </div>
                                <p class="mt-4 text-sm font-medium text-slate-500">
                                    <?php echo e(request()->filled('search') ? 'رویدادی با این مشخصات پیدا نشد.' : 'هنوز رویدادی ثبت نشده است.'); ?>

                                </p>
                                <?php if (! (request()->filled('search'))): ?>
                                    <a href="<?php echo e(route('admin.events.create')); ?>" class="mt-3 inline-block text-sm font-semibold text-indigo-600 hover:text-indigo-800 transition-colors">
                                        ایجاد اولین رویداد
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <?php if($events->hasPages()): ?>
            <div class="px-5 py-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <p class="text-xs text-slate-500">
                    نمایش <?php echo e($events->firstItem()); ?> تا <?php echo e($events->lastItem()); ?> از <?php echo e($events->total()); ?> رویداد
                </p>
                <div dir="ltr">
                    <?php echo e($events->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\admin\events\index.blade.php ENDPATH**/ ?>