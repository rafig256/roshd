

<?php $__env->startSection('title', 'درخواست تبدیل تیم به شرکت'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $companyTypes = [
        'private_joint_stock' => 'سهامی خاص',
        'public_joint_stock' => 'سهامی عام',
        'limited_liability'   => 'مسئولیت محدود',
        'general_partnership' => 'تضامنی',
        'other'               => 'دیگر',
    ];

    $inputBase = 'w-full px-4 py-3 text-sm rounded-xl border bg-slate-50 placeholder:text-slate-400
                  focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition';
    $inputLtr  = 'text-left placeholder:text-right';
?>

<section class="relative overflow-hidden bg-gradient-to-b from-indigo-50 via-white to-white min-h-[calc(100vh-5rem)]">

    
    <div class="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full bg-indigo-300/30 blur-3xl"></div>
    <div class="pointer-events-none absolute top-48 -left-24 w-80 h-80 rounded-full bg-fuchsia-300/20 blur-3xl"></div>

    <div class="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">

        
        <a href="<?php echo e(route('user.organizations.show', $organization->id)); ?>"
           class="inline-flex items-center gap-1.5 mb-6 text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                <path d="M9 5l7 7-7 7"/>
            </svg>
            بازگشت به مدیریت تیم
        </a>

        
        <div class="flex items-start gap-4">
            <div class="w-14 h-14 shrink-0 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                    <path d="M3 21h18M5 21V5a2 2 0 012-2h10a2 2 0 012 2v16M9 7h2M13 7h2M9 11h2M13 11h2M10 21v-4h4v4"/>
                </svg>
            </div>
            <div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900">درخواست تبدیل تیم به شرکت</h1>
                <p class="mt-2 text-sm sm:text-base leading-8 text-slate-600">
                    برای تبدیل تیم «<?php echo e($organization->name); ?>» به شرکت رسمی، مشخصات ثبتی شرکت را وارد کنید.
                    پس از بررسی توسط کارشناسان، نتیجه از طریق پنل کاربری اعلام می‌شود.
                </p>
            </div>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="mt-8 px-4 py-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
                لطفاً خطاهای مشخص‌شده در فرم را برطرف کنید و دوباره تلاش کنید.
            </div>
        <?php endif; ?>

        
        <div class="mt-8 bg-white rounded-2xl border border-slate-200 shadow-xl shadow-slate-900/5">
            <form method="POST" action="<?php echo e(route('user.organizations.convert-to-company.store', $organization->id)); ?>"
                  class="p-6 sm:p-8 space-y-6" novalidate>
                <?php echo csrf_field(); ?>

                
                <?php if($organization->company_rejection_reason): ?>
                    <div class="p-4 bg-red-50 border border-red-200 rounded-xl">
                        <p class="font-semibold text-red-800">درخواست قبلی شما برای تبدیل به شرکت رد شده بود.</p>
                        <p class="mt-1 text-sm text-red-700">دلیل رد: <?php echo e($organization->company_rejection_reason); ?></p>
                        <p class="mt-2 text-sm text-red-600">می‌توانید اطلاعات را اصلاح کرده و مجدداً ارسال کنید.</p>
                    </div>
                <?php endif; ?>

                
                <div>
                    <label for="legal_name" class="block mb-2 text-sm font-medium text-slate-700">
                        نام رسمی شرکت <span class="text-red-500">*</span>
                    </label>
                    <input type="text" id="legal_name" name="legal_name" value="<?php echo e(old('legal_name')); ?>"
                           maxlength="255" placeholder="نام ثبت‌شده‌ی شرکت در اداره‌ی ثبت شرکت‌ها"
                           class="<?php echo e($inputBase); ?> <?php $__errorArgs = ['legal_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['legal_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    
                    <div>
                        <label for="national_id" class="block mb-2 text-sm font-medium text-slate-700">
                            شناسه ملی <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="national_id" name="national_id" value="<?php echo e(old('national_id')); ?>"
                               dir="ltr" inputmode="numeric" maxlength="11" placeholder="۱۱ رقم"
                               class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="registration_number" class="block mb-2 text-sm font-medium text-slate-700">
                            شماره ثبت <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="registration_number" name="registration_number" value="<?php echo e(old('registration_number')); ?>"
                               dir="ltr" inputmode="numeric" maxlength="50" placeholder="شماره ثبت شرکت"
                               class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['registration_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['registration_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="economic_code" class="block mb-2 text-sm font-medium text-slate-700">
                            کد اقتصادی <span class="text-xs font-normal text-slate-400">(اختیاری)</span>
                        </label>
                        <input type="text" id="economic_code" name="economic_code" value="<?php echo e(old('economic_code')); ?>"
                               dir="ltr" inputmode="numeric" maxlength="20" placeholder="کد اقتصادی"
                               class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['economic_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['economic_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-slate-700">
                            تاریخ تأسیس <span class="text-red-500">*</span>
                        </label>

                        
                        <input type="hidden" id="established_date" name="established_date" value="<?php echo e(old('established_date')); ?>">

                        <div class="datepicker-wrap rounded-xl border bg-slate-50 transition
                                    focus-within:bg-white focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-indigo-500
                                    <?php $__errorArgs = ['established_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <persian-datepicker-element
                                id="established_date_picker"
                                placeholder="1403/01/01"
                                format="YYYY/MM/DD"
                                rtl
                                class="block w-full"></persian-datepicker-element>
                        </div>
                        <?php $__errorArgs = ['established_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div>
                    <label for="company_type" class="block mb-2 text-sm font-medium text-slate-700">
                        نوع شرکت <span class="text-red-500">*</span>
                    </label>
                    <select id="company_type" name="company_type"
                            class="<?php echo e($inputBase); ?> <?php $__errorArgs = ['company_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">یک نوع را انتخاب کنید</option>
                        <?php $__currentLoopData = $companyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('company_type') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['company_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="legal_address" class="block mb-2 text-sm font-medium text-slate-700">
                        آدرس حقوقی <span class="text-red-500">*</span>
                    </label>
                    <textarea id="legal_address" name="legal_address" rows="3"
                              placeholder="نشانی ثبت‌شده‌ی شرکت را کامل وارد کنید..."
                              class="<?php echo e($inputBase); ?> leading-7 resize-y <?php $__errorArgs = ['legal_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('legal_address')); ?></textarea>
                    <?php $__errorArgs = ['legal_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    
                    <div>
                        <label for="phone" class="block mb-2 text-sm font-medium text-slate-700">
                            تلفن <span class="text-xs font-normal text-slate-400">(اختیاری)</span>
                        </label>
                        <input type="text" id="phone" name="phone" value="<?php echo e(old('phone')); ?>"
                               dir="ltr" inputmode="tel" maxlength="20" placeholder="02100000000"
                               class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="email" class="block mb-2 text-sm font-medium text-slate-700">
                            ایمیل <span class="text-xs font-normal text-slate-400">(اختیاری)</span>
                        </label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                               dir="ltr" inputmode="email" maxlength="255" placeholder="info@example.com"
                               class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div>
                    <label for="website" class="block mb-2 text-sm font-medium text-slate-700">
                        وب‌سایت <span class="text-xs font-normal text-slate-400">(اختیاری)</span>
                    </label>
                    <input type="text" id="website" name="website" value="<?php echo e(old('website')); ?>"
                           dir="ltr" inputmode="url" maxlength="255" placeholder="https://example.com"
                           class="<?php echo e($inputBase); ?> <?php echo e($inputLtr); ?> <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php else: ?> border-slate-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                    <a href="<?php echo e(route('user.organizations.show', $organization->id)); ?>"
                       class="px-6 py-3 text-center text-sm font-semibold text-slate-600 rounded-xl border border-slate-300 hover:bg-slate-50 transition-colors">
                        انصراف
                    </a>
                    <button type="submit"
                            class="inline-flex items-center justify-center gap-2 px-8 py-3 text-sm font-bold text-white rounded-xl
                                   bg-gradient-to-l from-indigo-600 to-fuchsia-500 shadow-lg shadow-indigo-500/30
                                   hover:shadow-xl hover:-translate-y-0.5
                                   focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all">
                        ثبت درخواست تبدیل
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                             stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                            <path d="M19 12H5M11 6l-6 6 6 6"/>
                        </svg>
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    persian-datepicker-element { display: block; width: 100%; font-family: 'Vazirmatn', Tahoma, sans-serif; }
    .datepicker-wrap { padding: 0.25rem 0.5rem; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="module" src="https://cdn.jsdelivr.net/npm/persian-datepicker-element@1.1.17/dist/persian-datepicker-element.min.js"></script>

<script>
    // Persian datepicker <-> hidden input sync
    (function () {
        const picker = document.getElementById('established_date_picker');
        const hidden = document.getElementById('established_date');
        if (!picker || !hidden) return;

        const pad = (n) => String(n).padStart(2, '0');
        const toLatin = (s) => String(s)
            .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
            .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

        picker.addEventListener('change', (e) => {
            const j = e.detail && e.detail.jalali;
            hidden.value = Array.isArray(j) && j.length === 3
                ? `${j[0]}/${pad(j[1])}/${pad(j[2])}`
                : '';
        });

        // بازگرداندن old('established_date') بعد از خطای اعتبارسنجی
        const m = toLatin(hidden.value || '').trim().match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
        if (m) {
            customElements.whenDefined('persian-datepicker-element').then(() => {
                picker.setValue(+m[1], +m[2], +m[3]);
            });
        }
    })();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\rafig\project\roshd\resources\views\user\organizations\convert-to-company.blade.php ENDPATH**/ ?>